import { Home } from "@mui/icons-material"
import { useNavigate } from "react-router-dom"
import bg2 from "../../Assests/Content/07/breadcrumbs_bg.jpg"

const Section1 = ({ data, menu }) => {
  const navigate = useNavigate()
  function formatSlug(slug) {
    return slug
      .split("-")
      .map((word) => (word.toLowerCase() === "whats" ? "WhatsApp" : word.charAt(0).toUpperCase() + word.slice(1)))
      .join(" ")
  }
  return (
    <>
      <div className="">
        <div
          className="relative h-[35vh] w-full "
          // style={{
          //   backgroundImage: `url(${data?.cover?.url ? process.env.REACT_APP_API_URL + data?.cover?.url : bg2})`,
          //   backgroundSize: "cover",
          //   backgroundPosition: "center",
          //   backgroundRepeat: "no-repeat",
          //   // backgroundAttachment: "fixed",
          // }}
        >
          <img
            src={data?.cover?.url ? process.env.REACT_APP_API_URL + data?.cover?.url : bg2}
            alt="Cover"
            className="relative h-[35vh] w-full"
          />
          <div className="bg-black bg-opacity-30 blur-sm absolute top-0 h-full w-full left-0 flex justify-center items-center "></div>
          <div className="flex flex-col  text-white absolute top-[15%]  justify-between px-[3%] lg:px-[7%] gap-4 ">
            <div className="text-xs lg:text-base whitespace-nowrap text-wrap font-semibold  gap-2  ">
              <Home
                className="hover:cursor-pointer hover:!text-red-600 !capitalize mb-2"
                onClick={() => navigate("/")}
              />{" "}
              / {formatSlug(menu)} / {data?.title}
            </div>
            <div className="text-base lg:text-3xl text-wrap my-2 font-semibold ">{data?.title}</div>
            <div className="lg:w-[75%] !text-sm font-thin space border-l-2 p-1 border-red-700 pl-4 ">
              {data?.description}
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
export default Section1

{
  /* <CustomButton variant="outlined" className="!text-white border-3 font-bold !border-white !rounded-full" > GET IN TOUCH <ArrowForwardIosIcon className="!text-base" /></CustomButton> */
}
